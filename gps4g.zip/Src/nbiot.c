#include "nbiot.h"
#include "stdlib.h"
#include "string.h"
#include "usart.h"	
#include "tim.h"	
#include "stm32f4xx_hal.h"
#include "gpio.h"
#include "stdio.h"
#include "stdbool.h"
#include "stm32f4xx_it.h"
#include "gps.h"	
#include "main.h"	

extern uint8_t USART2_RX_STA;
extern uint8_t gUart1ReceBuf[UART1RX_MAX_LENGTH]; // ����1���ջ�����
uint8_t USART2_RX_BUF[256];
volatile uint32_t last_heartbeat_time = 0;
volatile uint8_t heartbeat_received = 0;
const uint32_t heartbeat_interval = 10000; // 10 seconds
const uint32_t timeout = 60000; // 1 minute
/*
��������send_NB_IoT
��  �ܣ��������ݵ�NBģ��
��  ����cmd Ҫ���͵����ݻ�������
*/
/*����2TX����ΪPA2��RX����ΪPA3*/
/*����2�����������ݵ�nbiotģ��*/
void send_NB_IoT(const char* cmd) {
	if (cmd == NULL) 
	return;
    while (*cmd != '\0') 
	{
		   HAL_UART_Transmit(&huart2, ( uint8_t*)cmd, 1, 1000);
           cmd++;
    }
//		HAL_UART_Transmit(&huart2, (uint8_t*)cmd, strlen(cmd), 1000);//������͵�NBģ��

}

uint8_t NB_IoT_ack_check(const char* str) {
    HAL_Delay(10);
	
    if (USART2_RX_STA != 0) {
        USART2_RX_STA = 0;
//		HAL_UART_Transmit(&huart3, USART2_RX_BUF,strlen((const char*)USART2_RX_BUF), 1000);//����Ӧ���ݷ��͵�����

        if (strstr((const char*)USART2_RX_BUF, str)) {
            memset(USART2_RX_BUF, 0, strlen((const char*)USART2_RX_BUF));
            return 0;
        } else {
            memset(USART2_RX_BUF, 0, strlen((const char*)USART2_RX_BUF));
            return 1;
        }
    } else {
        memset(USART2_RX_BUF, 0, strlen((const char*)USART2_RX_BUF));
        return 1;
    }
}

uint8_t NB_IotConnect(void) 
{
    send_NB_IoT("AT\r\n");
	if(NB_IoT_ack_check("OK") != 0)
	{
		return 1;
	}
	else
		return 0;
}

void nbiot_reset(void) {
    send_NB_IoT("AT+QRST=1");
    HAL_Delay(5000);
}


uint8_t NB_IoT_ZDFW(void) {
    uint8_t success_count = 0;
    uint8_t cmd_index = 1;
    int command_success ; 
    while (cmd_index <= 5) {
        switch (cmd_index) {
			 case 1:
                send_NB_IoT("AT+QSCLK=0\r\n");
                command_success = NB_IoT_ack_check("OK");
                break;
            case 2:
                send_NB_IoT("AT+CFUN=1\r\n");
                command_success = NB_IoT_ack_check("OK");
                break;
            case 3:
                send_NB_IoT("AT+CIMI\r\n");
                command_success = NB_IoT_ack_check("460");
                break;
            case 4:
                send_NB_IoT("AT+CSQ\r\n");
                HAL_Delay(10);
                if (USART2_RX_BUF[7] > '1' && USART2_RX_BUF[7] < '4') {
                    command_success = 0;
                } else {
                    memset(USART2_RX_BUF, 0, sizeof(USART2_RX_BUF));
                    USART2_RX_STA = 0;
                    command_success = 1;
                }
			   if (USART2_RX_STA != 0 && strlen((const char*)USART2_RX_BUF) > 7) {
						command_success = (USART2_RX_BUF[7] > '1' && USART2_RX_BUF[7] < '4');
				      if (USART2_RX_BUF[7] > '1' && USART2_RX_BUF[7] < '4') 
						{
						command_success = 0; // ʧ��
						}
			   else 
				   {
						command_success = 1; // ���û�н��յ����ݣ���Ϊʧ��
					}
				}
                break;
            case 5:
                send_NB_IoT("AT+CGATT?\r\n");
                command_success = NB_IoT_ack_check("+CGATT:1");
                break;
        }

        if (command_success==0)
		{
            success_count++;
            cmd_index++;
        }
		else
			return 1;
    }


    return (success_count == 5) ? 0 : 1; 
}




uint8_t NB_IoT_connect_MQTT(void) {
    uint8_t success_count = 0;
    uint8_t cmd_index = 1;
    int command_success = 0; 
//	int retry_count = 0;			/*��ǰ�������Դ���*/
//    const int max_retries = 3;		/*������Դ���*/

    while (cmd_index <= 4) {
        switch (cmd_index) {
            case 1:
                // ��MQTT�ͻ�������
                send_NB_IoT("AT+QMTOPEN=0,\"47.92.146.210\",1883\r\n");
			command_success = NB_IoT_ack_check("+OMTOPEN:0,0");
                break;
            case 2:
                // ���ӿͻ��˵�MQTT������
                send_NB_IoT("AT+QMTCONN=0,\"861428040040199\"\r\n");
			command_success = NB_IoT_ack_check("+QMTCONN:0,0,0");
                break;
//            case 3:
//                // ����MQTT�û��������루�����Ҫ��
//                send_NB_IoT("AT+NMGU=\"username\",\"password\"\r\n");
//                command_success = NB_IoT_ack_check("OK");
//                break;
            case 3:
                // ��������
                send_NB_IoT("AT+QMTSUB=0,1,\"bc25\",0\r\n");
                command_success = NB_IoT_ack_check("OK");
                break;
            case 4:
                // ����������Ϣ
                send_NB_IoT("AT+QMTPUB=0,0,0,0,\"bc25\",\"Hello MQTT\"\r\n");
                command_success = NB_IoT_ack_check("OK");
                break;
//            case 5:
//                // ����͸��ģʽ
//                send_NB_IoT("AT+ENTER_TRANSPARENT_MODE\r\n");
//                command_success = NB_IoT_ack_check("OK");
//                break;
        }

        if (command_success==0) {
            success_count++;
            cmd_index++;
//			retry_count = 0;
        }
		else {
//            retry_count++;
//            if (retry_count > max_retries) {
                return 1;
//				}
			}
		}
    return (success_count == 4) ? 0 : 1; 

}

void TIM2_IRQHandler(void) {
    HAL_TIM_IRQHandler(&htim2);
    
    // ÿ10�뷢��һ��������
    send_NB_IoT("AT\r\n");
    last_heartbeat_time = HAL_GetTick(); 
    heartbeat_received = 0;

    // �����������Ӧ
    if (NB_IoT_ack_check("OK") == 0) {
        heartbeat_received = 1;
    }
	
    // ���1������û���յ���������Ӧ������ģ�鲢��������
    if ((heartbeat_received==0) && (HAL_GetTick() - last_heartbeat_time >= timeout)) {
        nbiot_reset();
        HAL_Delay(5000);
	uint8_t NB_IotConnect();
	uint8_t NB_IoT_ZDFW();
	uint8_t NB_IoT_connect_MQTT();
    }
}

void NB_IOT_Init(void)
{
	uint8_t NB_IotConnect();
	uint8_t NB_IoT_ZDFW();
	uint8_t NB_IoT_connect_MQTT();
	TIM2_IRQHandler();
	if (NB_IotConnect() != 0) { // ��������Ƿ�ɹ�
		HAL_GPIO_WritePin(GPIOF, GPIO_PIN_9, GPIO_PIN_RESET);
	}
		if (NB_IoT_ZDFW() != 0) { // ��������Ƿ�ɹ�
		HAL_GPIO_WritePin(GPIOF, GPIO_PIN_10, GPIO_PIN_RESET);
		}
}







void send_UART_data_to_MQTT() {
    char mqtt_message[300];
    snprintf(mqtt_message, sizeof(mqtt_message), "AT+QMTPUB=0,0,0,0,\"bc25\",\"%s\"\r\n", gUart1ReceBuf);
    send_NB_IoT(mqtt_message);
    if (NB_IoT_ack_check("OK") != 0) {
//        HAL_GPIO_TogglePin(GPIOF, GPIO_PIN_9 | GPIO_PIN_10);
    }
}
//void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
//    if (huart->Instance == USART2) {
//        // Process received data
//		USART2_RX_STA = 1;
//        send_UART_data_to_MQTT();
//        // Restart UART receive interrupt
//        HAL_UART_Receive_IT(&huart2, USART2_RX_BUF, sizeof(USART2_RX_BUF));
//    }
//}





 






