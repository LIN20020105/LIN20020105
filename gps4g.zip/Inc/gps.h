#ifndef __GPS_H__
#define __GPS_H__

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "main.h"

extern UART_HandleTypeDef huart1;
void gps_init(void);




#define UART1RX_MAX_LENGTH 256 




#ifdef __cplusplus
}
#endif

#endif /* __GPS_H__ */
