/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __NBIOT_H__
#define __NBIOT_H__

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "main.h"
extern UART_HandleTypeDef huart2;
void NB_IOT_Init(void);
void send_NB_IoT(const char* cmd);

uint8_t NB_IoT_ack_check(const char* str);
uint8_t NB_IotConnect(void);
void nbiot_reset(void);
uint8_t NB_IoT_connect_MQTT(void);
void send_UART_data_to_MQTT(void) ;
#ifdef __cplusplus
}
#endif

#endif /* __NBIOT_H__ */
